This a Notice App for Banasthali Vidyapith
